import sqlite3

conn = sqlite3.connect('database.db')
print("Connected to database successfully")



# Add the 'clubname' column to the 'events' table
conn.execute('ALTER TABLE events ADD COLUMN clubname TEXT')

print("Created table successfully and added the 'clubname' column!")

conn.close()
