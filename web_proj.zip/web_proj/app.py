                  from flask import Flask, render_template, request, redirect, jsonify
import sqlite3
import hashlib

app = Flask(__name__, template_folder='templates')
DB_FILE = "database.db"
def create_database():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS events (
            
            title TEXT NOT NULL,
            start_event DATETIME NOT NULL,
            end_event DATETIME NOT NULL,
            location TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

create_database()

@app.route('/')
def home():
    return render_template('loginpg.html')
def check_password(username, password_to_check):
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        # Execute a SQL query to retrieve the password for the given username
        cursor.execute('SELECT password FROM users WHERE username = ?', (username,))
        stored_password = cursor.fetchone()
        print(stored_password)
        input_password = password_to_check
        if stored_password:
            stored_password = stored_password[0]
            print(stored_password)
            # Hash the provided password and compare it to the stored password
            if input_password == stored_password:
                return True  # Passwords match
            else:
                return False  # Passwords do not match
        else:
            return False  # Username not found

    except sqlite3.Error as e:
        print("SQLite error:", e)
        return False  # Return False on error

    finally:
        conn.close()


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if check_password(username, password):
            # Redirect to the view page on successful login
            return render_template('view.html')

    # Render login page if login fails or if it's a GET request
    return render_template('loginpg.html')

@app.route('/view')
def view():
    # Add code here to render the view page
    return render_template('view.html')
next_user_id = 10


@app.route('/calendar.html')
def calendar():
    return render_template('calendar.html')
@app.route('/Clubs.html')
def clubs():
    return render_template('Clubs.html')
@app.route('/Registration.html')
def Registration():
    return render_template('Registration.html')
#@app.route('/stats.html')
#def stats():
    return render_template('stats.html')

@app.route('/calendar')
def calendar_page():
    events = get_events()
    DB_FILE = "database.db"
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM events ORDER BY id")
    calendar = cursor.fetchall()
    conn.close()
    return render_template('calendar.html', events=events)
@app.route("/insert", methods=["POST", "GET"])
def insert():
    if request.method == 'POST':
        title = request.form['title']
        start = request.form['start']
        end = request.form['end']
        club_name = request.form['club_name']
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO events (title, start_event, end_event, club_name) VALUES (?, ?, ?, ?)", (title, start, end, club_name))
        conn.commit()
        conn.close()
        msg = 'success'
        return jsonify(msg)

@app.route("/update", methods=["POST", "GET"])
def update():
    if request.method == 'POST':
        title = request.form['title']
        start = request.form['start']
        end = request.form['end']
        club_name = request.form['club_name']
        id = request.form['id']
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("UPDATE events SET title = ?, start_event = ?, end_event = ?, club_name = ? WHERE id = ?", (title, start, end, club_name, id))
        conn.commit()
        conn.close()
        msg = 'success'
        return jsonify(msg)

@app.route("/ajax_delete", methods=["POST", "GET"])
def ajax_delete():
    if request.method == 'POST':
        getid = request.form['id']
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute('DELETE FROM events WHERE id = ?', (getid,))
        conn.commit()
        conn.close()
        msg = 'Record deleted successfully'
        return jsonify(msg)
# ... (existing code)
# ... (your existing code)

@app.route('/register_event', methods=['POST'])
def register_event():
    if request.method == 'POST':
        title = request.form['name']
        start_event = request.form['date'] + ' ' + request.form['time']
        location = request.form['location']
        details = request.form['description']

        # Connect to the database
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        # Insert the event into the "events" table
        cursor.execute('INSERT INTO events (title, start_event, end_event, location) VALUES (?, ?, ?, ?)', (title, start_event, start_event, location))
        conn.commit()
        conn.close()

        return render_template('view.html')  # Redirect to page after successful registration
    else:
        return render_template('Registration.html')

# ... (rest of the code)
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm-password']

        if password == confirm_password:
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()
            cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
            conn.commit()
            conn.close()

            # You can customize the response or redirect to a different page
            return render_template('loginpg.html')
        else:
            # Passwords do not match, you can handle this as needed (e.g., show an error message)
            return render_template('signup.html', error="Passwords do not match")

    # Render the signup page if it's a GET request or if the passwords don't match
    return render_template('signup.html')


if __name__ == "__main__":
    app.run(debug=True)

# ... (other imports and code)

@app.route('/stats.html')
                                    
def stats():
    render_template('stats.html')
    # Fetch data from the events table
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM events")
    event_data = cursor.fetchall()
    conn.close()

    # Pass the event data to the stats.html template
    return render_template('stats.html', events=event_data)

# ... (other routes and code)


if __name__ == "_main_":
    app.run(debug=True)