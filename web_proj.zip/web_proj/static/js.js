const passwordField = document.getElementById('password');
const confirmPasswordField = document.getElementById('confirm-password');
const errorMessage = document.querySelector('.error-message');

confirmPasswordField.addEventListener('input', () => {
    if (confirmPasswordField.value === passwordField.value) {
        errorMessage.classList.remove('match-error');
        errorMessage.classList.add('match-success');
        errorMessage.textContent = 'Passwords match!';
    } else {
        errorMessage.classList.remove('match-success');
        errorMessage.classList.add('match-error');
        errorMessage.textContent = 'Passwords do not match.';
    }
});
